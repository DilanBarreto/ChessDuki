package exportacion_y_movimientos;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EscritordePGN {

    private GameMetadata metadatos;
    private Registrador_de_Movimientos registradordeMovimientos;

    public EscritordePGN(GameMetadata metadatos, Registrador_de_Movimientos registradordeMovimientos) {
        this.metadatos = metadatos;
        this.registradordeMovimientos = registradordeMovimientos;
    }

    /**
     * Escribir los datos PGN en un archivo dentro de la carpeta "src/partidas".
     *
     * @param nombreArchivo Nombre del archivo para guardar el PGN.
     */
    public void escribirEnArchivo(String nombreArchivo) {
        // Ruta relativa de la carpeta de partidas
        String nombreCarpeta = "src" + File.separator + "partidas";

        // Crear el directorio si no existe
        File carpeta = new File(nombreCarpeta);
        if (!carpeta.exists()) {
            if (carpeta.mkdirs()) { // Usamos mkdirs() para rutas anidadas
                System.out.println("Directorio 'src/partidas' creado exitosamente.");
            } else {
                System.err.println("Error: No se pudo crear el directorio 'src/partidas'.");
                return;
            }
        }

        // Asegurar que el archivo tenga la extensión ".pgn"
        if (!nombreArchivo.endsWith(".pgn")) {
            nombreArchivo += ".pgn";
        }

        // Crear la ruta completa del archivo
        String rutaCompleta = nombreCarpeta + File.separator + nombreArchivo;

        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(rutaCompleta))) {
            // Escribir metadatos
            String metadatosPGN = metadatos.toString();
            if (metadatosPGN.isEmpty()) {
                System.err.println("Error: Los metadatos están vacíos. No se puede generar el archivo PGN.");
                return;
            }
            escritor.write(metadatosPGN);
            escritor.newLine();
            escritor.newLine();

            // Escribir movimientos
            String movimientosPGN = registradordeMovimientos.obtenerPGN();
            if (movimientosPGN.isEmpty()) {
                System.err.println("Advertencia: No hay movimientos para escribir.");
            } else {
                escritor.write(movimientosPGN);
                escritor.newLine();
            }

            System.out.println("Archivo PGN guardado exitosamente en: " + rutaCompleta);
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }

    }
}

