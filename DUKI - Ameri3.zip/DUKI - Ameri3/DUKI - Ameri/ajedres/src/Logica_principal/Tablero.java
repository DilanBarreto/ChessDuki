package Logica_principal;

import Piezas.*;
import exportacion_y_movimientos.Registrador_de_Movimientos;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.sound.sampled.*;

public class Tablero extends JPanel {
    private JTextArea areaMovimientos;
    public int tamanoCasilla = 85;
    int columnas = 8;
    int filas = 8;
    Registrador_de_Movimientos registradordeMovimientos = new Registrador_de_Movimientos(this);
    ArrayList<Pieza> listaPiezas = new ArrayList<>();

    public Pieza piezaSeleccionada;
    public boolean esTurnoBlanco = true;
    public boolean juegoTerminado = false;
    ints entrada = new ints(this);
    int contadorDesplazamientos = 0;
    public int casillaEnPassant = -1;
    public Verificador_de_jaque_mate verificadorDejaquemate = new Verificador_de_jaque_mate(this);

    private final Color colorCasillaClara = new Color(108, 154, 211);
    private final Color colorCasillaOscura = new Color(58, 95, 174);
    private final Color colorBorde = new Color(10, 20, 99);

    private static final String SOUND_PATH = "src/recursos/movimiento.wav";

    public Tablero() {
        this.setPreferredSize(new Dimension(columnas * tamanoCasilla, filas * tamanoCasilla));
        this.addMouseListener(entrada);
        this.addMouseMotionListener(entrada);
        this.setBorder(BorderFactory.createLineBorder(colorBorde, 3));
        this.setBackground(colorBorde);
        agregarPiezas();
    }

    public void reproducirSonido() {
        try {
            File sonido = new File(SOUND_PATH);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(sonido);
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    public Pieza obtenerPieza(int col, int fila) {
        for (Pieza pieza : listaPiezas) {
            if (pieza.col == col && pieza.row == fila) {
                return pieza;
            }
        }
        return null;
    }

    public void realizarMovimiento(Movimiento_de_las_piezas movimiento) {
        if (movimiento.pieza.nombre.equals("Peón")) {
            moverPeon(movimiento);
        } else if (movimiento.pieza.nombre.equals("Rey")) {
            moverRey(movimiento);
        }

        movimiento.pieza.col = movimiento.nuevaCol;
        movimiento.pieza.row = movimiento.nuevaRow;
        movimiento.pieza.xPos = movimiento.nuevaCol * tamanoCasilla;
        movimiento.pieza.yPos = movimiento.nuevaRow * tamanoCasilla;
        movimiento.pieza.esPrimerMovimiento = false;

        capturar(movimiento.captura);
        registradordeMovimientos.registrarMovimiento(movimiento);
        contadorDesplazamientos++;
        esTurnoBlanco = !esTurnoBlanco;
        actualizarEstadoJuego();

        if (areaMovimientos != null) {
            areaMovimientos.setText(registradordeMovimientos.obtenerPGN());
            areaMovimientos.setCaretPosition(areaMovimientos.getDocument().getLength());
        }

        reproducirSonido();
    }

    private void moverRey(Movimiento_de_las_piezas movimiento) {
        if (Math.abs(movimiento.pieza.col - movimiento.nuevaCol) == 2) {
            Pieza torre = (movimiento.pieza.col < movimiento.nuevaCol) ? obtenerPieza(7, movimiento.pieza.row) : obtenerPieza(0, movimiento.pieza.row);
            torre.col = (movimiento.pieza.col < movimiento.nuevaCol) ? 5 : 3;
            torre.xPos = torre.col * tamanoCasilla;
        }
    }

    private void moverPeon(Movimiento_de_las_piezas movimiento) {
        int indiceColor = movimiento.pieza.esBlanca ? 1 : -1;

        if (obtenerNumeroCasilla(movimiento.nuevaCol, movimiento.nuevaRow) == casillaEnPassant) {
            movimiento.captura = obtenerPieza(movimiento.nuevaCol, movimiento.nuevaRow + indiceColor);
        }
        if (Math.abs(movimiento.pieza.row - movimiento.nuevaRow) == 2) {
            casillaEnPassant = obtenerNumeroCasilla(movimiento.nuevaCol, movimiento.nuevaRow + indiceColor);
        } else {
            casillaEnPassant = -1;
        }

        indiceColor = movimiento.pieza.esBlanca ? 0 : 7;
        if (movimiento.nuevaRow == indiceColor) {
            promoverPeon(movimiento);
        }
    }

    private void promoverPeon(Movimiento_de_las_piezas movimiento) {
        listaPiezas.add(new Reina(this, movimiento.nuevaCol, movimiento.nuevaRow, movimiento.pieza.esBlanca));
        capturar(movimiento.pieza);
    }

    public void capturar(Pieza pieza) {
        listaPiezas.remove(pieza);
    }

    public boolean esMovimientoValido(Movimiento_de_las_piezas movimiento) {
        if (juegoTerminado) return false;
        if (movimiento.pieza.esBlanca != esTurnoBlanco) return false;
        if (mismoEquipo(movimiento.pieza, movimiento.captura)) return false;
        if (!movimiento.pieza.esMovimientoValido(movimiento.nuevaCol, movimiento.nuevaRow)) return false;
        if (movimiento.pieza.movimientoColisionaConPieza(movimiento.nuevaCol, movimiento.nuevaRow)) return false;
        if (verificadorDejaquemate.esReyEnJaque(movimiento)) return false;
        return true;
    }

    public boolean mismoEquipo(Pieza p1, Pieza p2) {
        if (p1 == null || p2 == null) return false;
        return p1.esBlanca == p2.esBlanca;
    }

    public int obtenerNumeroCasilla(int col, int fila) {
        return fila * columnas + col;
    }

    public Pieza encontrarRey(boolean esBlanco) {
        for (Pieza pieza : listaPiezas) {
            if (esBlanco == pieza.esBlanca && pieza.nombre.equals("Rey")) {
                return pieza;
            }
        }
        return null;
    }

    public void asignarAreaMovimientos(JTextArea area) {
        this.areaMovimientos = area;
    }

    public void agregarPiezas() {
        listaPiezas.add(new Caballo(this, 1, 0, false));
        listaPiezas.add(new Caballo(this, 6, 0, false));
        listaPiezas.add(new Torre(this, 0, 0, false));
        listaPiezas.add(new Torre(this, 7, 0, false));
        listaPiezas.add(new Alfil(this, 2, 0, false));
        listaPiezas.add(new Alfil(this, 5, 0, false));
        listaPiezas.add(new Reina(this, 3, 0, false));
        listaPiezas.add(new Rey(this, 4, 0, false));
        for (int i = 0; i < columnas; i++) {
            listaPiezas.add(new Peon(this, i, 1, false));
        }

        listaPiezas.add(new Caballo(this, 1, 7, true));
        listaPiezas.add(new Caballo(this, 6, 7, true));
        listaPiezas.add(new Torre(this, 0, 7, true));
        listaPiezas.add(new Torre(this, 7, 7, true));
        listaPiezas.add(new Alfil(this, 2, 7, true));
        listaPiezas.add(new Alfil(this, 5, 7, true));
        listaPiezas.add(new Reina(this, 3, 7, true));
        listaPiezas.add(new Rey(this, 4, 7, true));
        for (int i = 0; i < columnas; i++) {
            listaPiezas.add(new Peon(this, i, 6, true));
        }
    }

    private void actualizarEstadoJuego() {
        Pieza rey = encontrarRey(esTurnoBlanco);
        if (verificadorDejaquemate.esJuegoTerminado(rey)) {
            if (verificadorDejaquemate.esReyEnJaque(new Movimiento_de_las_piezas(this, rey, rey.col, rey.row))) {
                System.out.println(esTurnoBlanco ? "Las negras ganan" : "Las blancas ganan");
            } else {
                System.out.println("Empate");
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        for (int r = 0; r < filas; r++) {
            for (int c = 0; c < columnas; c++) {
                g2d.setColor((c + r) % 2 == 0 ? colorCasillaClara : colorCasillaOscura);
                g2d.fillRect(c * tamanoCasilla, r * tamanoCasilla, tamanoCasilla, tamanoCasilla);
            }
        }

        for (Pieza pieza : listaPiezas) {
            pieza.pintar(g2d);
        }

        g2d.setFont(new Font("Segoe UI", Font.BOLD, 14));
        for (int i = 0; i < 8; i++) {
            g2d.setColor((i % 2 == 0) ? colorCasillaOscura : colorCasillaClara);
            g2d.drawString(String.valueOf(8 - i), 5, i * tamanoCasilla + 20);

            g2d.setColor(((i + 7) % 2 == 0) ? colorCasillaOscura : colorCasillaClara);
            g2d.drawString(String.valueOf((char) ('A' + i)), i * tamanoCasilla + tamanoCasilla - 15,
                    filas * tamanoCasilla - 5);
        }
    }
}
